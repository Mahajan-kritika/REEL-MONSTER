# Reel Monster

Reel Monster is a native Kotlin Android app for locally tracking short-video habits. It includes manual counting, a draggable overlay counter, locally stored daily totals, a seven-day view, and an opt-in accessibility heuristic for Instagram Reels and YouTube Shorts.

Automatic detection is experimental. It relies on labels exposed by the apps' accessibility trees and is not guaranteed to identify each video or every app version. Manual counting is the reliable fallback.

## Requirements (Windows)

- 64-bit JDK 17
- Android SDK command-line tools
- Android SDK Platform 35, Build Tools 35.0.0, and Platform Tools
- Android Gradle Plugin downloads require an internet connection during the first build

Android Studio is not required.

### Install and configure the command-line environment

1. Install a JDK 17 distribution, for example:

   ```powershell
   winget install EclipseAdoptium.Temurin.17.JDK
   ```

2. Download the **Command line tools only** package from the official Android developer site: <https://developer.android.com/studio#command-line-tools-only>. Extract it so this file exists:

   ```text
   %LOCALAPPDATA%\Android\Sdk\cmdline-tools\latest\bin\sdkmanager.bat
   ```

   If the extracted folder is named `cmdline-tools`, put its contents under `cmdline-tools\latest` (the `bin` folder must be directly inside `latest`).

3. Configure the SDK and install the required packages (in a new PowerShell window):

   ```powershell
   $sdk = "$env:LOCALAPPDATA\Android\Sdk"
   [Environment]::SetEnvironmentVariable("ANDROID_HOME", $sdk, "User")
   [Environment]::SetEnvironmentVariable("ANDROID_SDK_ROOT", $sdk, "User")
   $env:ANDROID_HOME = $sdk
   $env:ANDROID_SDK_ROOT = $sdk
   & "$sdk\cmdline-tools\latest\bin\sdkmanager.bat" --licenses
   & "$sdk\cmdline-tools\latest\bin\sdkmanager.bat" "platform-tools" "platforms;android-35" "build-tools;35.0.0"
   ```

   Accept the SDK licenses when prompted. Ensure the JDK's `bin` directory is on `PATH` and `JAVA_HOME` points to the JDK 17 installation.

4. Open a new terminal in this project and build:

   ```powershell
   .\gradlew.bat assembleDebug
   ```

   The wrapper downloads Gradle 8.9 on first use. The project uses Android Gradle Plugin 8.7.3, which requires JDK 17 and Gradle 8.9 or newer.

## Install on a connected Android device

Enable Developer options and USB debugging on the device, connect it, then run:

```powershell
adb install -r .\app\build\outputs\apk\debug\app-debug.apk
```

The debug APK is written to `app\build\outputs\apk\debug\app-debug.apk` after a successful build.

## Permissions and tracking

- **Display over other apps:** On Start Tracking, the app explains why the permission is needed before opening Android's overlay settings. It is used only for the draggable counter.
- **Accessibility:** Choose Automatic mode to see an explanation, then enable Reel Monster yourself under Android Accessibility settings. Android does not allow the app to enable this permission itself.
- **Foreground service:** Starting tracking shows an ongoing notification while the overlay/tracking session runs. Stop Tracking ends the session.
- **Notifications:** The service notification is used to make the ongoing session visible to the user.

Manual counts, settings, and daily history are kept in app-private SharedPreferences. Dates use the device's local calendar date; moving to a new date creates a new daily record without erasing prior dates. Estimated time is count multiplied by the configured average duration (15 seconds by default); it is not measured playback time.

Automatic mode only looks for visible accessibility text containing labels such as “Reel” or “Shorts” and a changed visible-text signature. This conservative heuristic can miss videos, count a UI change as a video, or stop working when Instagram or YouTube changes its UI. It does not record the screen, take screenshots, inspect passwords or private messages, or send content over the network. The app requests no network permission.

## Project layout

- `app/src/main/java/com/reelmonster/app/MainActivity.kt` — dashboard and controls
- `app/src/main/java/com/reelmonster/app/StatsStore.kt` — local counts, settings, and history
- `app/src/main/java/com/reelmonster/app/TrackingService.kt` — foreground session and overlay bubble
- `app/src/main/java/com/reelmonster/app/ReelAccessibilityService.kt` — local, opt-in detection heuristic
- `app/src/main/AndroidManifest.xml` — app permissions and services

## Validation status

This source project has not been built or tested on a device in the current environment because the JDK, Android SDK, Gradle, ADB, and Android device are unavailable. Follow [TESTING.md](./TESTING.md) after installing the toolchain. Do not treat automatic counting as accurate until it has been checked against the exact supported app versions and a real device.
