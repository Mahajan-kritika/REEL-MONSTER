package com.reelmonster.app

import android.content.Context
import java.time.LocalDate

data class DayStats(
    val date: LocalDate,
    val instagram: Int,
    val youtube: Int
) {
    val total: Int get() = instagram + youtube
}

object StatsStore {
    private const val PREFS = "reel_monster"
    private const val LAST_PLATFORM = "last_platform"
    private const val MODE = "tracking_mode"
    private const val PAUSED = "tracking_paused"
    private const val DURATION = "average_duration"
    private const val ACTIVE_PLATFORM = "active_platform"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun key(date: LocalDate, platform: String) = "${date}_$platform"

    @Synchronized
    fun increment(context: Context, platform: String) {
        val safePlatform = if (platform == "youtube") "youtube" else "instagram"
        val store = prefs(context)
        val date = LocalDate.now()
        store.edit()
            .putInt(key(date, safePlatform), store.getInt(key(date, safePlatform), 0) + 1)
            .putString(LAST_PLATFORM, "$date:$safePlatform")
            .apply()
        TrackingService.refreshOverlay(context)
    }

    @Synchronized
    fun undo(context: Context): Boolean {
        val store = prefs(context)
        val value = store.getString(LAST_PLATFORM, null) ?: return false
        val parts = value.split(':')
        if (parts.size != 2 || parts[0] != LocalDate.now().toString()) return false
        val date = LocalDate.parse(parts[0])
        val countKey = key(date, parts[1])
        val count = store.getInt(countKey, 0)
        if (count <= 0) return false
        store.edit().putInt(countKey, count - 1).remove(LAST_PLATFORM).apply()
        TrackingService.refreshOverlay(context)
        return true
    }

    fun today(context: Context): DayStats = forDate(context, LocalDate.now())

    fun forDate(context: Context, date: LocalDate) = DayStats(
        date,
        prefs(context).getInt(key(date, "instagram"), 0),
        prefs(context).getInt(key(date, "youtube"), 0)
    )

    fun lastSevenDays(context: Context): List<DayStats> =
        (6 downTo 0).map { forDate(context, LocalDate.now().minusDays(it.toLong())) }

    fun durationSeconds(context: Context) =
        prefs(context).getInt(DURATION, 15).coerceIn(5, 120)

    fun setDurationSeconds(context: Context, seconds: Int) {
        prefs(context).edit().putInt(DURATION, seconds.coerceIn(5, 120)).apply()
    }

    fun isAutomatic(context: Context) =
        prefs(context).getString(MODE, "manual") == "automatic"

    fun setAutomatic(context: Context, automatic: Boolean) {
        prefs(context).edit().putString(MODE, if (automatic) "automatic" else "manual").apply()
    }

    fun isPaused(context: Context) = prefs(context).getBoolean(PAUSED, false)

    fun activePlatform(context: Context) =
        prefs(context).getString(ACTIVE_PLATFORM, "instagram") ?: "instagram"

    fun setActivePlatform(context: Context, platform: String) {
        prefs(context).edit()
            .putString(ACTIVE_PLATFORM, if (platform == "youtube") "youtube" else "instagram")
            .apply()
    }

    fun setPaused(context: Context, paused: Boolean) {
        prefs(context).edit().putBoolean(PAUSED, paused).apply()
        TrackingService.refreshOverlay(context)
    }

    @Synchronized
    fun resetToday(context: Context) {
        val today = LocalDate.now()
        prefs(context).edit()
            .remove(key(today, "instagram"))
            .remove(key(today, "youtube"))
            .remove(LAST_PLATFORM)
            .apply()
        TrackingService.refreshOverlay(context)
    }

    fun message(count: Int): String = when {
        count >= 50 -> "Your thumb needs a vacation!"
        count >= 30 -> "HELP! WE LIVE HERE NOW!"
        count >= 20 -> "Feed me more!"
        count >= 10 -> "I'm getting hungry!"
        count >= 5 -> "Getting comfortable, aren't we?"
        count >= 1 -> "Just one? I believe you!"
        else -> "Ready when you are!"
    }

    fun stage(count: Int): String = when {
        count > 50 -> "Reel Monster"
        count >= 31 -> "Overfed Monster"
        count >= 16 -> "Growing Monster"
        count >= 6 -> "Hungry Monster"
        else -> "Baby Monster"
    }
}
