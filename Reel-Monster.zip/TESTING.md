# Reel Monster test checklist

These are manual device tests; they have not been run in the current environment.

## Build and installation

- [ ] Run `.\gradlew.bat assembleDebug` on Windows with JDK 17 and Android SDK Platform 35 installed.
- [ ] Install `app\build\outputs\apk\debug\app-debug.apk` with `adb install -r`.
- [ ] Confirm the app launches and counts/history survive force-stop and device restart.

## Manual mode

- [ ] Start tracking and grant overlay permission only after reviewing the explanation.
- [ ] Drag the bubble; verify it does not steal focus or prevent tapping the underlying app.
- [ ] Count reels manually in Instagram and YouTube; verify totals and per-platform counts.
- [ ] Verify pause, stop, restart, undo, reset-today, and previous-day history behavior.
- [ ] Change the average duration and confirm the display remains labeled estimated.

## Automatic mode

- [ ] Select Automatic mode and enable the accessibility service manually in Android Settings.
- [ ] In Instagram Reels and YouTube Shorts, compare counts against at least 20 known item transitions.
- [ ] Repeat accessibility events on the same item and check for duplicate increments.
- [ ] Scroll ordinary feeds and other screens to check that they are not counted.
- [ ] Leave each supported app and verify no new counts are recorded outside it.
- [ ] Record app versions, device/Android version, missed counts, and duplicate counts.

Automatic counting is UI-label-dependent and may not meet the requested error tolerance. If the short-video UI exposes no usable label or changes its accessibility tree, document the failure and rely on manual mode; do not report an unverified accuracy result.
