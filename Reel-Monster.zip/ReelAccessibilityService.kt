package com.reelmonster.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ReelAccessibilityService : AccessibilityService() {
    private var activePackage: String? = null
    private var lastItemSignature: String? = null
    private var lastCountAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val packageName = event.packageName?.toString() ?: return
        val platform = when (packageName) {
            INSTAGRAM_PACKAGE -> "instagram"
            YOUTUBE_PACKAGE -> "youtube"
            else -> null
        }
        activePackage = platform?.let { packageName }
        if (platform == null) return
        StatsStore.setActivePlatform(this, platform)
        if (!StatsStore.isAutomatic(this) || StatsStore.isPaused(this)) return

        val root = rootInActiveWindow ?: return
        val evidence = collectVisibleEvidence(root)
        if (!evidence.first) return
        val signature = evidence.second
        val now = android.os.SystemClock.elapsedRealtime()
        if (signature == lastItemSignature || now - lastCountAt < DEBOUNCE_MS) return

        lastItemSignature = signature
        lastCountAt = now
        StatsStore.increment(this, platform)
    }

    private fun collectVisibleEvidence(root: AccessibilityNodeInfo): Pair<Boolean, String> {
        val values = ArrayList<String>()
        var shortVideoLabel = false

        fun visit(node: AccessibilityNodeInfo, depth: Int) {
            if (depth > 12 || values.size >= 100) return
            val text = listOf(node.text, node.contentDescription)
                .filterNotNull()
                .joinToString(" ")
                .trim()
            if (text.isNotEmpty()) {
                val normalized = text.lowercase()
                if (normalized.contains("reel") || normalized.contains("shorts") ||
                    normalized.contains("short video")) shortVideoLabel = true
                if (values.size < 30) values.add(normalized.take(80))
            }
            for (index in 0 until node.childCount) {
                node.getChild(index)?.let { child ->
                    visit(child, depth + 1)
                    child.recycle()
                }
            }
        }

        visit(root, 0)
        return shortVideoLabel to values.joinToString("|")
    }

    override fun onInterrupt() = Unit

    companion object {
        private const val INSTAGRAM_PACKAGE = "com.instagram.android"
        private const val YOUTUBE_PACKAGE = "com.google.android.youtube"
        private const val DEBOUNCE_MS = 1_800L
    }
}
