package com.reelmonster.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private var startAfterNotificationPermission = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized) render()
    }

    private fun render() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(0xFFF7F1FF.toInt())
            isFillViewport = true
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(28))
        }
        scroll.addView(content)
        setContentView(scroll)

        val today = StatsStore.today(this)
        val count = today.total
        val seconds = count * StatsStore.durationSeconds(this)
        val automatic = StatsStore.isAutomatic(this)
        val paused = StatsStore.isPaused(this)

        text("REEL MONSTER", 14f, 0xFF7651AE.toInt(), true, Gravity.CENTER)
        text("Meet Your Reel Monster!", 27f, 0xFF342347.toInt(), true, Gravity.CENTER)
        text(
            "Every scroll feeds your monster. Are you ready to see how big it gets?",
            15f, 0xFF675C73.toInt(), false, Gravity.CENTER
        )
        text(if (count < 16) "👾" else if (count < 31) "👹" else "🧌", 84f, 0xFF8357D1.toInt(), true, Gravity.CENTER)
        text(StatsStore.stage(count), 19f, 0xFF4E3A67.toInt(), true, Gravity.CENTER)
        text(StatsStore.message(count), 16f, 0xFF7651AE.toInt(), false, Gravity.CENTER)

        card {
            text("$count", 42f, 0xFF342347.toInt(), true, Gravity.CENTER)
            text("reels today", 15f, 0xFF675C73.toInt(), false, Gravity.CENTER)
            text(
                "Instagram: ${today.instagram}   YouTube: ${today.youtube}",
                14f, 0xFF675C73.toInt(), false, Gravity.CENTER
            )
            text("Estimated scrolling: ${formatTime(seconds)}", 15f, 0xFF4E3A67.toInt(), true, Gravity.CENTER)
        }

        card {
            text(
                "Tracking: ${if (paused) "Paused" else if (automatic) "Automatic (approximate)" else "Manual"}",
                16f, 0xFF342347.toInt(), true
            )
            text(
                "Overlay: ${if (Settings.canDrawOverlays(this@MainActivity)) "allowed" else "not enabled"}  •  " +
                    "Accessibility: ${if (isAccessibilityEnabled()) "enabled" else "not enabled"}",
                13f, 0xFF675C73.toInt()
            )
            row {
                button(if (paused) "Start tracking" else "Stop tracking") {
                    if (paused) startTracking() else stopTracking()
                }
                button(if (automatic) "Manual mode" else "Automatic mode") {
                    chooseMode()
                }
            }
            button("Accessibility setup & privacy") { explainAccessibility() }
        }

        card {
            text("Count a reel", 18f, 0xFF342347.toInt(), true)
            text("Manual counts can be entered for either supported app.", 13f, 0xFF675C73.toInt())
            row {
                button("+ Instagram") { increment("instagram") }
                button("+ YouTube") { increment("youtube") }
            }
            row {
                button("Undo last") {
                    Toast.makeText(
                        this@MainActivity,
                        if (StatsStore.undo(this@MainActivity)) "Last count undone" else "Nothing to undo today",
                        Toast.LENGTH_SHORT
                    ).show()
                    render()
                }
                button("Reset today") { confirmReset() }
            }
        }

        card {
            text("Last seven days", 18f, 0xFF342347.toInt(), true)
            val week = StatsStore.lastSevenDays(this)
            val maximum = (week.maxOfOrNull { it.total } ?: 0).coerceAtLeast(1)
            week.forEach { day ->
                val label = day.date.format(DateTimeFormatter.ofPattern("EEE", Locale.getDefault()))
                val bar = TextView(this).apply {
                    text = "$label  ${"■".repeat((day.total * 12 / maximum).coerceAtLeast(if (day.total > 0) 1 else 0))}  ${day.total}"
                    textSize = 14f
                    setTextColor(0xFF7651AE.toInt())
                    setPadding(0, dp(4), 0, dp(4))
                }
                content.addView(bar)
            }
            val total = week.sumOf { it.total }
            val average = total / 7.0
            val highest = week.maxByOrNull { it.total }
            text("Weekly total: $total   •   Daily average: ${"%.1f".format(Locale.getDefault(), average)}", 14f, 0xFF675C73.toInt())
            text("Highest day: ${highest?.date?.format(DateTimeFormatter.ofPattern("EEE, MMM d", Locale.getDefault())) ?: "—"}", 14f, 0xFF675C73.toInt())
        }

        card {
            text("Settings & privacy", 18f, 0xFF342347.toInt(), true)
            text("Time is an estimate: count × your chosen average reel duration.", 13f, 0xFF675C73.toInt())
            button("Average duration: ${StatsStore.durationSeconds(this)} sec") { editDuration() }
            text(
                "Your counts stay on this device. No account, internet, analytics, screenshots, or screen recording. " +
                    "Automatic detection uses accessibility labels locally and may miss or miscount videos.",
                13f, 0xFF675C73.toInt()
            )
        }
    }

    private fun text(
        value: String,
        size: Float,
        color: Int,
        bold: Boolean = false,
        gravity: Int = Gravity.START
    ) {
        val view = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            this.gravity = gravity
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(5), 0, dp(5))
        }
        content.addView(view)
    }

    private fun card(block: LinearLayout.() -> Unit) {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFFFFFFFF.toInt())
                cornerRadius = dp(20).toFloat()
            }
            elevation = dp(2).toFloat()
        }
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = dp(12)
        }
        content.addView(container, params)
        val previous = content
        content = container
        block()
        content = previous
    }

    private fun row(block: LinearLayout.() -> Unit) {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        content.addView(layout)
        val previous = content
        content = layout
        block()
        content = previous
    }

    private fun button(label: String, action: () -> Unit) {
        val view = Button(this).apply {
            text = label
            textSize = 13f
            setOnClickListener { action() }
        }
        val params = if (content.orientation == LinearLayout.HORIZONTAL) {
            LinearLayout.LayoutParams(0, dp(48), 1f)
        } else {
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48))
        }.apply {
                topMargin = dp(4)
                bottomMargin = dp(2)
            }
        content.addView(view, params)
    }

    private fun increment(platform: String) {
        StatsStore.increment(this, platform)
        render()
    }

    private fun startTracking() {
        if (!Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this)
                .setTitle("Allow the monster bubble?")
                .setMessage("Reel Monster needs Android's display-over-other-apps permission to show a draggable counter over Instagram or YouTube. It only displays the count.")
                .setNegativeButton("Not now", null)
                .setPositiveButton("Continue") { _, _ ->
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
                .show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            startAfterNotificationPermission = true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_REQUEST)
            return
        }
        continueStartingTracking()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == NOTIFICATION_PERMISSION_REQUEST && startAfterNotificationPermission) {
            startAfterNotificationPermission = false
            if (grantResults.firstOrNull() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Tracking can run, but Android may hide its notification.", Toast.LENGTH_LONG).show()
            }
            continueStartingTracking()
        }
    }

    private fun continueStartingTracking() {
        StatsStore.setPaused(this, false)
        startTrackingService()
        render()
    }

    private fun startTrackingService() {
        val intent = Intent(this, TrackingService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
    }

    private fun stopTracking() {
        StatsStore.setPaused(this, true)
        stopService(Intent(this, TrackingService::class.java))
        render()
    }

    private fun chooseMode() {
        val options = arrayOf("Level 1 — Manual counting", "Level 2 — Automatic (experimental)")
        AlertDialog.Builder(this)
            .setTitle("Choose tracking level")
            .setItems(options) { _, choice ->
                StatsStore.setAutomatic(this, choice == 1)
                if (choice == 1) explainAccessibility()
                render()
            }
            .show()
    }

    private fun explainAccessibility() {
        AlertDialog.Builder(this)
            .setTitle("Why Accessibility access?")
            .setMessage(
                "Automatic mode checks visible accessibility labels on Instagram and YouTube to look for “Reel” or “Shorts” and changes between visible items. Detection is approximate and app updates can break it. Data stays on this device; no screen recording, screenshots, passwords, messages, or network transmission are used. You must enable the service yourself in Android Settings."
            )
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Open Accessibility Settings") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .show()
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.contains("$packageName/${ReelAccessibilityService::class.java.name}", ignoreCase = true)
    }

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setTitle("Reset today's count?")
            .setMessage("This clears only today's Instagram and YouTube counts. Previous days remain saved.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Reset") { _, _ ->
                StatsStore.resetToday(this)
                render()
            }
            .show()
    }

    private fun editDuration() {
        val input = android.widget.EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(StatsStore.durationSeconds(this@MainActivity).toString())
            hint = "5–120 seconds"
        }
        AlertDialog.Builder(this)
            .setTitle("Average seconds per reel")
            .setMessage("Used only to estimate scrolling time (default: 15 seconds).")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val value = input.text.toString().toIntOrNull()
                if (value == null || value !in 5..120) {
                    Toast.makeText(this, "Enter a number from 5 to 120", Toast.LENGTH_SHORT).show()
                } else {
                    StatsStore.setDurationSeconds(this, value)
                    render()
                }
            }
            .show()
    }

    private fun formatTime(totalSeconds: Int): String {
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return if (minutes > 0) "${minutes}m ${seconds}s (estimated)" else "${seconds}s (estimated)"
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val NOTIFICATION_PERMISSION_REQUEST = 701
    }
}
